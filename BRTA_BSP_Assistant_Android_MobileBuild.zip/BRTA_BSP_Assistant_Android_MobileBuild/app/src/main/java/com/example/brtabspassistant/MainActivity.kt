package com.example.brtabspassistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.brtabspassistant.data.AppDatabase
import com.example.brtabspassistant.data.Applicant
import com.example.brtabspassistant.ui.ApplicantAdapter
import com.example.brtabspassistant.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: AppDatabase
    private lateinit var adapter: ApplicantAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "bsp_assistant.db").build()
        adapter = ApplicantAdapter { a -> openApplicant(a) }
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter

        b.bspButton.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://bsp.brta.gov.bd/")))
        }
        b.addButton.setOnClickListener {
            startActivity(Intent(this, ApplicantFormActivity::class.java))
        }

        lifecycleScope.launch {
            db.applicantDao().all().collectLatest { adapter.submit(it) }
        }
    }

    private fun openApplicant(a: Applicant) {
        val i = Intent(this, ApplicantDetailActivity::class.java)
        i.putExtra("name", a.fullName)
        i.putExtra("nid", a.nid)
        i.putExtra("mobile", a.mobile)
        i.putExtra("dob", a.dob)
        startActivity(i)
    }
}
