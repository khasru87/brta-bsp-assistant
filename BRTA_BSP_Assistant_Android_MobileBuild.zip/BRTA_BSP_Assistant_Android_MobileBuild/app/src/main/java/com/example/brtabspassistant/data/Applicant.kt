package com.example.brtabspassistant.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "applicants")
data class Applicant(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val dob: String,
    val nid: String,
    val mobile: String,
    val email: String = "",
    val address: String = "",
    val notes: String = ""
)
