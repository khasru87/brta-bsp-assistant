package com.example.brtabspassistant

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.example.brtabspassistant.data.AppDatabase
import com.example.brtabspassistant.data.Applicant
import com.example.brtabspassistant.databinding.ActivityFormBinding
import kotlinx.coroutines.launch

class ApplicantFormActivity : ComponentActivity() {
    private lateinit var b: ActivityFormBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFormBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.save.setOnClickListener {
            val name=b.name.text.toString().trim()
            val dob=b.dob.text.toString().trim()
            val nid=b.nid.text.toString().trim()
            val mobile=b.mobile.text.toString().trim()
            if(name.isEmpty()||dob.isEmpty()||nid.isEmpty()||mobile.isEmpty()){
                Toast.makeText(this,"নাম, জন্মতারিখ, NID ও মোবাইল দিন",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                val db=Room.databaseBuilder(applicationContext,AppDatabase::class.java,"bsp_assistant.db").build()
                db.applicantDao().insert(Applicant(
                    fullName=name,dob=dob,nid=nid,mobile=mobile,
                    email=b.email.text.toString(),address=b.address.text.toString(),notes=b.notes.text.toString()
                ))
                runOnUiThread {
                    Toast.makeText(this@ApplicantFormActivity,"Applicant সংরক্ষণ হয়েছে",Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}
