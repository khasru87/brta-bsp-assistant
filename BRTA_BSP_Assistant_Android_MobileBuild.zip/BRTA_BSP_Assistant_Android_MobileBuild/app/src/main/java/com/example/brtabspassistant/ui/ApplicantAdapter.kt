package com.example.brtabspassistant.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.brtabspassistant.data.Applicant
import com.example.brtabspassistant.databinding.ItemApplicantBinding

class ApplicantAdapter(
    private val onClick: (Applicant) -> Unit
) : RecyclerView.Adapter<ApplicantAdapter.VH>() {
    private var items = listOf<Applicant>()
    fun submit(list: List<Applicant>) { items = list; notifyDataSetChanged() }
    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemApplicantBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, p: Int) = h.bind(items[p])
    inner class VH(private val b: ItemApplicantBinding): RecyclerView.ViewHolder(b.root) {
        fun bind(a: Applicant) {
            b.name.text = a.fullName
            b.details.text = "NID: ${a.nid} • ${a.mobile}"
            b.root.setOnClickListener { onClick(a) }
        }
    }
}
