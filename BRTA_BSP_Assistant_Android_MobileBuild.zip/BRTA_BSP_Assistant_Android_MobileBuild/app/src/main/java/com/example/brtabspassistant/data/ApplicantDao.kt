package com.example.brtabspassistant.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ApplicantDao {
    @Query("SELECT * FROM applicants ORDER BY id DESC")
    fun all(): Flow<List<Applicant>>

    @Query("""SELECT * FROM applicants
        WHERE fullName LIKE '%' || :q || '%'
        OR nid LIKE '%' || :q || '%'
        OR mobile LIKE '%' || :q || '%'
        ORDER BY id DESC""")
    fun search(q: String): Flow<List<Applicant>>

    @Insert
    suspend fun insert(a: Applicant)

    @Delete
    suspend fun delete(a: Applicant)
}
