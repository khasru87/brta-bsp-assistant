package com.example.brtabspassistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.google.android.material.button.MaterialButton

class ApplicantDetailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val name=intent.getStringExtra("name") ?: ""
        val nid=intent.getStringExtra("nid") ?: ""
        val mobile=intent.getStringExtra("mobile") ?: ""
        val dob=intent.getStringExtra("dob") ?: ""
        val root=android.widget.LinearLayout(this).apply {
            orientation=android.widget.LinearLayout.VERTICAL
            setPadding(24,24,24,24)
        }
        root.addView(TextView(this).apply { text="Applicant Profile"; textSize=24f })
        root.addView(TextView(this).apply { text="\n$name\nDOB: $dob\nNID: $nid\nMobile: $mobile"; textSize=18f })
        root.addView(MaterialButton(this).apply {
            text="BSP Registration খুলুন"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://bsp.brta.gov.bd/register?lan=bn")))
            }
        })
        root.addView(TextView(this).apply {
            text="\nনিরাপত্তা: CAPTCHA/Security Code ও OTP নিজে সম্পন্ন করতে হবে।"
        })
        setContentView(root)
    }
}
