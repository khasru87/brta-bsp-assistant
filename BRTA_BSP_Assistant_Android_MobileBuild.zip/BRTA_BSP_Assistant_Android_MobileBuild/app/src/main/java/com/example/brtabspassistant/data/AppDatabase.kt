package com.example.brtabspassistant.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Applicant::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun applicantDao(): ApplicantDao
}
